/* CC2-2019 - lab7 */

public interface Ordenable {
	public boolean mayorQue(Ordenable x);
	public boolean menorQue(Ordenable x);
	public boolean mayorOIgualA(Ordenable x);
	public boolean menorOIgualA(Ordenable x);
	public boolean igualA(Ordenable x);
}
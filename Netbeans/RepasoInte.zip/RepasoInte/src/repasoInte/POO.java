/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoInte;

/**
 *
 * @author toshiba2
 */
public class POO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        

      //instanciar: crear un objeto
//      Scanner ingreso= new Scanner(System.in);
                                                  //ventaja de poo puede ingresarse mas de uno
       //        Tv nuevaTvL= new Tv();
//        la public class de la clase normal tambien se debe llamar Tv

       //set y get
//       se crean en la clase normal

//       y se llaman en la Main asi
//               System.out.println("Ingrese 2 marc");
//       --> nuevaTvL.setMarca(ingreso.next());
//        --> System.out.println("la 2 marca es: "+nuevaTvL.getMarca());
        
        
//Mostrar todo de una
// System.out.println(nuevaTvL.toString());

    }
    
}

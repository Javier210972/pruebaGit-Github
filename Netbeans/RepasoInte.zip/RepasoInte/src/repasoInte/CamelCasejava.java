/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoInte;

/**
 *
 * @author toshiba2
 */
public class CamelCasejava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        CAMEL CASE EN JAVA
1 Implica si una letra es Mayusculas / Minusculas, de ahi se la conoce como Camello
1.1 TIPOS
1.1.1 UpperCamelCase
1.1.1.1 Cuando la primera letra de cada una de las palabras es mayúscula
1.1.2 LowerCamelCase
1.1.2.1 Igual que el anterior con la excepción que la primera es minúscula
2 Usos en JAVA
2.1 CLASES E INTERFACES
2.1.1 - La primera letra mayúscula - Usa nomenclatura CamelCase - Las clases deben ser sustantivos - Las interfaces nombres deben ser adjetivos
2.2 PAQUETES
2.2.1 - Escrito todo en minúscula - Van después de la palabra reservada package - Si se van a usar paquetes dentro de otros paquetes, se unen mediante un punto(.) - Finalizan con ;
2.3 MÉTODOS
2.3.1 - La primer letra debe ser minúscula - Utiliza nomenclatura camelCase - Los nombres deben conformarse por el par verbo + sustantivo - El nombre va después del tipo de método (void, int, double, String)
2.4 VARIABLES
2.4.1 - La primer letra debe ser minúscula - Utiliza nomenclatura camelCase - El nombre va después del tipo de dato (int, String, double, boolean) - Es recomendable utilizar nombres con un significado explícito, y en lo posible, cortos
2.5 CONSTANTES
2.5.1 - Todas las letras de cada palabra deben estar en mayúsculas - Se separa cada palabra con un _ - Se declaran similar a las variables, con la diferencia de que el tipo de dato va después de la palabra reservada final
        */
    }
    
}

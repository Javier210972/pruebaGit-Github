/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoInte;

/**
 *
 * @author toshiba2
 */
public class PooJavaClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        public class Tv {
////    se definira atributo y metodos
//
//    //Atributo
//    private String marca;
//    private String tipo;
//    private int tamanio;//la Ñ es un caracter especial(no se usa)
//    private double precio;
//    private boolean estado;
//    //METODOS
//
//    public Tv(String marca,String tipo,int tamanio,double precio){
////     Metodo Constructor
//     this.marca=marca;
//     this.tipo=tipo;
//     this.estado=false;//false=apagado-true=encendido
//     this.tamanio=tamanio;
//     this.precio=precio;
//        System.out.println("television creada");
//    }
//    //sobre cargar metodo
//    public Tv(){
//        //Constructor
//    }
//    //Metodo de acceso


//Mostrar todo
//@Override
//    public String toString() {
//        return "Tv{" + "marca=" + marca + ", tipo=" + tipo + ", tamanio=" + tamanio + ", precio=" + precio + ", estado=" + estado + '}';
//    }

    }
    
}

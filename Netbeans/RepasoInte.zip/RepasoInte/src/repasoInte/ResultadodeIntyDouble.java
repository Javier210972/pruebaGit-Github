/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoInte;

import java.util.Scanner;

/**
 *
 * @author redes
 */
public class ResultadodeIntyDouble {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//       Scanner fibo = new Scanner(System.in);
//        int valor1;
//        int valor2;
//        int respuesta;
//        System.out.println("Ingrese");
//        valor1=fibo.nextInt();
//        valor2=valor1/3;
//        respuesta=valor2%2;
//        System.out.println(valor2);
        
        Scanner fibo = new Scanner(System.in);
        double valor1;
        double valor2;
        double respuesta;
        System.out.println("Ingrese");
        valor1=fibo.nextInt();
        valor2=valor1/3;
        respuesta=valor2%2;
        System.out.println(respuesta);

    }
    
}

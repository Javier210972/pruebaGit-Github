/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoInte;

/**
 *
 * @author toshiba2
 */
public class Operadores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Operadores
        /*
NombreOperador Utilización Resultado
AND	&&	A && B	verdadero cuando A y B son verdaderos. Evaluación condicional.
OR	||	A || B	verdadero cuando A o B son verdaderos. Evaluación condicional.
NOT	!	!A	verdadero si A es falso.
AND	&	A & B	verdadero cuando A y B son verdaderos. Siempre evalúa ambos operandos.
OR	|	A | B	verdadero cuando A o B son verdaderos. Siempre evalúa ambos operandos.
XOR	^	A ^ B	verdadero cuando A y B son diferentes
        !=              Diferente que
        ==              Igual que
        %                residuo de una division
        */
        
        //Metodo Parse
  /*método "parse", entre sus múltiples funciones, nos permite convertir caracteres númericos a datos numéricos
        , es decir, convertir un número almacenado como String a un dato del tipo int
        , double u otro según se requiera*/
    
        
    }
    
}
